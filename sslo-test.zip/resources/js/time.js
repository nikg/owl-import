eval:() => 
{
  let date = new Date(); 
  let dateStr = date.toTimeString();
  let str = dateStr.substr(0,5);
  return str
}
