function __hook_scenario_load(notifyObj) {
    const notifyInit = () => {
        if (window.utag) {
            window.utag_data = {
                subDomain: "simulator", // app / session
                language: "en_US", // app / session
            };
        }
        else {
            setTimeout(() => notifyInit(), 0);
        }
    }

    notifyInit();
}

function __hook_notify(notifyObj) {
    // Object Structure
    // scenario: this.normalize(scenarioId),
    // step: this.normalize(stepMeta.title),
    // screen: this.normalize(screenTitleInfo.title),
    // index: screenTitleInfo.mergedIndex,
    // url: url
    if (notifyObj.index) {
        window.utag.link({
            "link_text": "next",
            "event_type": "click",
            "event_name": `${notifyObj.step}:${notifyObj.screen}:step_${notifyObj.index}`,
            "tealium_event": "simulator_step"
        });
    }
    else {
        window.utag_data = {
            pageName: `simulator:f5.com:${notifyObj.scenario}:${notifyObj.step}:${notifyObj.screen}`,
            destinationUrl: notifyObj.url,
            primaryCategory: notifyObj.step,
            subCategory1: notifyObj.screen,
        };
        window.utag.view();
    }
}

function ctaClick() {
    cside.show("all-screen-form-marketo-sslo");
    window.cside.eval('form-open', 'CTA', 'sslo');
}